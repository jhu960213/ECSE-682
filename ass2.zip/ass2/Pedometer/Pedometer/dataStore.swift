//
//  chartData.swift
//  Pedometer
//
//  Created by Hamza Mian on 2020-10-17.
//

import Foundation
import Charts

var stepValues: [ChartDataEntry] = [ChartDataEntry(x: 0.0, y: 0.0)]/*,ChartDataEntry(x: 30.0, y: 10.0),ChartDataEntry(x: 60.0, y: 20.0),ChartDataEntry(x: 90.0, y: 30.0),ChartDataEntry(x: 120.0, y: 40.0)]*/
var liml: ChartLimitLine?

//
//protocol stepDelegate{
//    func onSetGoal (type: Int)
//}

