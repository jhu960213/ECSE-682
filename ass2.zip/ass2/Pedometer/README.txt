Instructions on how to open our project with Xcode:

- Since we are using third party libraries and modules for charting we added on cocoa pods
- Please open the project with the white Xcode project file
- The extention is: Pedometer.xcworkspace
- When running the application from the emulator it is best to choose an iPhone with
the largest screen size (ex: iPhone 11 Pro) as the charting y and x axis labels might be invisible
if one were to run it on a smaller sized emulator.
Note: Pedometer functionalities require the use of a real iPhone with sensor hardware
the emulators do not have sensing functionalities.
